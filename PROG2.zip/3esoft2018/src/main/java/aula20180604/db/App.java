package aula20180604.db;

import java.sql.Connection;

import javax.swing.JOptionPane;


public class App {
	
	public static void main(String[] args) {
		
		Connection conn = GerenciadorBD.abrirConexao();
		DAOLivro.criarTabela(conn);
		
		Livro bom = new Livro(1, "Conceitos de Computa��o com Java", 820);
		DAOLivro.inserir(conn, bom);
		JOptionPane.showMessageDialog(null, "Opa, incluiu!");
		
		Livro recuperado = DAOLivro.recuperarPeloId(conn, 1);
		System.out.println(recuperado.getTitulo());
		
		
		bom.setTitulo("B�blia Sagrada");
		DAOLivro.atualizar(conn, bom);
		
		recuperado = DAOLivro.recuperarPeloId(conn, 1);
		System.out.println(recuperado.getTitulo());

		JOptionPane.showMessageDialog(null, "Opa, atualizou!");
		
		
		DAOLivro.excluir(conn, bom.getId());
		
		System.out.println("Foi.");
		
	}

}

package aula20180604.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOLivro {
	public static void criarTabela(Connection conn) {
		try {
			conn.createStatement().execute(
					"create table if not exists livro ("
					+ "id integer not null primary key,"
					+ "titulo varchar(255) not null,"
					+ "numero_de_paginas integer not null)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void atualizar(Connection conn, Livro novo) {
		PreparedStatement psUpdate = null;
		try {
			String update = "update livro set titulo = ?, numero_de_paginas = ? where id=?";
			psUpdate = conn.prepareStatement(update);
			psUpdate.setInt(3, novo.getId());
			psUpdate.setString(1, novo.getTitulo());
			psUpdate.setInt(2, novo.getNumeroDePaginas());
			psUpdate.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				psUpdate.close();
			} catch (Exception e2) {
			}
		}		
	}

	public static void inserir(Connection conn, Livro novo) {
		PreparedStatement psInsert = null;
		try {
			String insert = "insert into livro (id, titulo, numero_de_paginas) values (?,?,?)";
			psInsert = conn.prepareStatement(insert);
			psInsert.setInt(1, novo.getId());
			psInsert.setString(2, novo.getTitulo());
			psInsert.setInt(3, novo.getNumeroDePaginas());
			psInsert.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				psInsert.close();
			} catch (Exception e2) {
			}
		}		
	}
	
	public static void excluir(Connection conn, Integer id) {
		try (PreparedStatement psDelete = conn.prepareStatement("delete from livro where id = ?");
		     Teste t = new Teste();) {
			psDelete.setInt(1, id);
			psDelete.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} 	
	}

	//Exemplo de classe implementando AutoCloseable para que possa ser usada em um try with resources (try com "par�nteses"). Ver exemplo do excluir.
	public static class Teste implements AutoCloseable {

		@Override
		public void close() throws Exception {
			System.out.println("Ulha que l�ko! Chamou o close() da classe Teste sozinho!!!! :D It's a kind of magic!");
			
		}
		
	}

	public static Livro recuperarPeloId(Connection conn, Integer id) {
		try (PreparedStatement psSelect = conn.prepareStatement("select titulo, numero_de_paginas, id from livro where id = ?")) {
			psSelect.setInt(1, id);
			ResultSet rsLivro = psSelect.executeQuery();
			if (rsLivro.next()) {
				Livro recuperado = new Livro(rsLivro.getInt("id"), rsLivro.getString("titulo"), rsLivro.getInt("numero_de_paginas"));
				return recuperado;
			} else {
				throw new LivroNaoEncontrado("N�o foi encontrado livro com id=" + id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static List<Livro> recuperarTodos(Connection conn) {
		List<Livro> livros = new ArrayList();
		try (PreparedStatement psSelect = conn.prepareStatement("select titulo, numero_de_paginas, id from livro")) {
			ResultSet rsLivro = psSelect.executeQuery();
			while (rsLivro.next()) {
				Livro recuperado = new Livro(rsLivro.getInt("id"), rsLivro.getString("titulo"), rsLivro.getInt("numero_de_paginas"));
				livros.add(recuperado);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return livros;
	}	
	
}


















package aula20180604.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class GerenciadorBD {

	public static Connection abrirConexao() {
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/3esoft2018",
					"postgres",
					"unicesumar");
			return conn;
		} catch (Exception vari�velQueTer�AExce��o) {
			System.out.println("Vixe, gerou uma exception!!!! ");
			System.out.println("Vamos ver do que se trata... ");
			vari�velQueTer�AExce��o.printStackTrace();
		}		
		return null;
	}

}

package aula20180604.db;

public class Livro {

	private int id;
	private String titulo;
	private int numeroDePaginas;

	public Livro(int id, String titulo, int numeroDePaginas) {
		this.id = id;
		this.titulo = titulo;
		this.numeroDePaginas = numeroDePaginas;
	}
	
	public int getId() {
		return id;
	}
	public int getNumeroDePaginas() {
		return numeroDePaginas;
	}
	public String getTitulo() {
		return titulo;
	}
	
	public void setNumeroDePaginas(int numeroDePaginas) {
		this.numeroDePaginas = numeroDePaginas;
	}
	
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

}

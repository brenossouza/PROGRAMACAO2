package aula20180604.db;

public class LivroNaoEncontrado extends RuntimeException {	
	
	public LivroNaoEncontrado(String mensagem) {
		super(mensagem);
	}
}

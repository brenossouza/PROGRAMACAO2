package aula20180615.exceptions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.swing.JOptionPane;

public class App {
	
	public static void main(String[] args) {
		ContaCorrente cc = new ContaCorrente();
		try {
			cc.debitar(100.00);
			cc.debitar(100.00);
			cc.debitar(100.00);
			cc.debitar(100.00);
			cc.debitar(100.00);
			cc.debitar(1000.00);
			cc.debitar(1000.00);
			cc.debitar(1000.00);
			cc.debitar(1000.00);
			cc.debitar(1000.00);
			cc.debitar(1000.00);
			cc.debitar(1000.00);
		} catch (LimiteExcedidoException e) {
			e.printStackTrace();
			System.out.println("Vixe! N�o debitou.... :(");
		}
		
		try {
			FileInputStream file = new FileInputStream("d:/arquivo.txt");
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Arquivo [arquivo.txt] n�o encontrado em d:\\, verifique.");
		}
	}

}

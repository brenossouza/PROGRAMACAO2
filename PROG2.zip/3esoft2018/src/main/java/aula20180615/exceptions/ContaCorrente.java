package aula20180615.exceptions;

public class ContaCorrente {
	private double limite = 5000.00;
	private double saldo = 0.00;
	
	public void debitar(double debito) throws LimiteExcedidoException {
		if ((saldo-debito)>(limite*-1)) {
			this.saldo -= debito;
		} else {
			throw new LimiteExcedidoException("O saldo � " + saldo + " e a tentativa de d�bito foi de " + debito);
		}
	}
	
	

}

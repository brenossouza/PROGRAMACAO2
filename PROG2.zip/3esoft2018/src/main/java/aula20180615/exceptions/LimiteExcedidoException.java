package aula20180615.exceptions;

public class LimiteExcedidoException extends Exception {

	//private String mensagem;

	public LimiteExcedidoException(String mensagem) {
		//this.mensagem = mensagem;
		super(mensagem);
	}

}

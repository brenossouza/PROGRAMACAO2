package aula20180618;

import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

public class App {
	public static void main(String[] args) throws ParseException {
		Connection conn = GerenciaBd.abriConexao();
		DAOAvaliacao.criarTabela(conn);

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date data = sdf.parse("20/11/2018");
		Avaliacao novo = new Avaliacao(15154162, 60.0, "esoft", data);
		DAOAvaliacao.inserir(conn, novo);
		JOptionPane.showMessageDialog(null, "Opa, incluiu!");

	//	DAOAvaliacao.excluir(conn, 15154162);

	}

}

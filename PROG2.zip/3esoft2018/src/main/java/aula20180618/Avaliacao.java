package aula20180618;



import java.util.Date;

public class Avaliacao {
 //new javaSQLDate(hoje.getTime());
	private Date data;	
	private int ra;
	private double nota;
	private String diciplina;
	
	public Avaliacao(int ra,double nota,String disciplina,Date data){
		this.ra =ra;
		this.data = data;
		this.diciplina = disciplina;
		this.nota = nota;
		}

	//create get and set alt+shift+S and R
	
    public Date getData() {
		return data;
	}
	
	public int getRa() {
		return ra;
	}

	public void setRa(int ra) {
		this.ra = ra;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public String getDiciplina() {
		return diciplina;
	}

	public void setDiciplina(String diciplina) {
		this.diciplina = diciplina;
	}
	
	
}

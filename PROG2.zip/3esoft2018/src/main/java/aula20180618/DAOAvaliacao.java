package aula20180618;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import aula20180604.db.DAOLivro.Teste;

public class DAOAvaliacao {

	public static void criarTabela(Connection conn) {
		try {
			conn.createStatement().execute(
					"create table if not exists avaliacao("
							+ "ra integer not null primary key,"
							+ "diciplina varchar(255) not null,"
							+ "nota DOUBLE PRECISION not null,"
							+ "data date not null)");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void inserir(Connection conn, Avaliacao nova) {
		PreparedStatement psInsert = null;
		try {
			String insert = "insert into avaliacao (ra, diciplina, nota,data) values (?,?,?,?)";
			psInsert = conn.prepareStatement(insert);
			psInsert.setInt(1, nova.getRa());
			psInsert.setString(2, nova.getDiciplina());
			psInsert.setDouble(3, nova.getNota());
			java.sql.Date dataConvertida = new java.sql.Date(nova.getData()
					.getTime());
			psInsert.setDate(4, dataConvertida);
			psInsert.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				psInsert.close();
			} catch (Exception e2) {
			}
		}
	}

	public static void excluir(Connection conn, Integer ra) {
		try (PreparedStatement psDelete = conn
				.prepareStatement("delete from avaliacao where ra = ?");) {
			psDelete.setInt(1, ra);
			psDelete.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package aula20180618;

import java.sql.Connection;
import java.sql.DriverManager;

public class GerenciaBd {

	public static Connection abriConexao() {
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/3esoft2018",
					"postgres",
					"unicesumar"
					);
			return conn;
			
		} catch (Exception variavelComExce��o) {
			System.out.println("Vixe, gerou uma exception!!!! ");
			System.out.println("Vamos ver do que se trata... ");
			variavelComExce��o.printStackTrace();
		}
		return null;
	}
	
	
}
